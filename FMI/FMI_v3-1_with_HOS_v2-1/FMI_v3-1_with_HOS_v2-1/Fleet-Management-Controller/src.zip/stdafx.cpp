// stdafx.cpp : source file that includes just the standard includes
// CFmiApplication.pch will be the pre-compiled header
// stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"
#include "CFmiApplication.h"

//! The one and only CFmiApplication object
CFmiApplication theApp;
